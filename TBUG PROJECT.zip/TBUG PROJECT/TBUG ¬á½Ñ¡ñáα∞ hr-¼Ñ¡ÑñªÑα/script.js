const navButtons = document.querySelectorAll('.nav .btn');

navButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Убираем класс "active" у всех кнопок
    navButtons.forEach(btn => btn.classList.remove('active'));
    // Добавляем класс "active" к текущей кнопке
    button.classList.add('active');
  });
});


const monthYear = document.getElementById('monthYear');
const daysContainer = document.getElementById('days');
const addEventBtn = document.getElementById('addEventBtn');
const popup = document.getElementById('popup');
const closePopup = document.querySelector('.close');
const saveEventBtn = document.getElementById('saveEvent');
const eventTitleInput = document.getElementById('eventTitle');
const eventDateInput = document.getElementById('eventDate');
const eventTimeInput = document.getElementById('eventTime');
const prevMonthBtn = document.getElementById('prevMonth');
const nextMonthBtn = document.getElementById('nextMonth');

let currentDate = new Date();
let events = {}; // Объект для хранения событий
const userRole = 'manager'; // Замените на 'admin' или 'leader' для тестирования

function renderCalendar() {
  const month = currentDate.getMonth();
  const year = currentDate.getFullYear();

  monthYear.textContent = `${month + 1}/${year}`; // Используем обратные кавычки для вставки переменных

  // Очистка контейнера с днями
  daysContainer.innerHTML = '';

  // Получение первого дня месяца
  const firstDayOfMonth = new Date(year, month, 1).getDay();

  // Заполнение пустыми ячейками
  for (let i = 0; i < firstDayOfMonth; i++) {
    const emptyDiv = document.createElement('div');
    daysContainer.appendChild(emptyDiv);
  }

  // Заполнение дней месяца
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let day = 1; day <= daysInMonth; day++) {
    const dayDiv = document.createElement('div');
    dayDiv.textContent = day;

    // Проверка на наличие событий для этого дня
    const eventKey = `${year}-${(month + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
    if (events[eventKey]) {
      events[eventKey].forEach(event => {
        const eventDiv = document.createElement('div');
        eventDiv.className = 'event';
        eventDiv.textContent = `${event.title} (${event.time})`; // Отображение названия события и времени
        dayDiv.appendChild(eventDiv);
      });
    }

    daysContainer.appendChild(dayDiv);

    // Добавление класса для прошлых дат
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Сбрасываем время в today
    if (new Date(year, month, day) < today) {
      dayDiv.classList.add('past-date');
    }

    // Добавление события на клик
    dayDiv.addEventListener('click', () => {
        alert(`Вы выбрали ${day}/${month + 1}/${year}`); // Используем обратные кавычки для вставки переменных
    });
   }
  }
  
  // Переход к предыдущему месяцу
  prevMonthBtn.addEventListener('click', () => {
   currentDate.setMonth(currentDate.getMonth() - 1);
   renderCalendar();
  });
  
  // Переход к следующему месяцу
  nextMonthBtn.addEventListener('click', () => {
   currentDate.setMonth(currentDate.getMonth() + 1);
   renderCalendar();
  });
  
  // Проверка роли пользователя и отображение кнопки добавления события
  if (userRole === 'admin' || userRole === 'leader') {
   addEventBtn.style.display = 'block';
  }
  
  // Открытие поп-апа для добавления события
  addEventBtn.addEventListener('click', () => {
   popup.style.display = 'block';
  });
  
  // Закрытие поп-апа
  closePopup.addEventListener('click', () => {
   popup.style.display = 'none';
  });
  
  // Сохранение события
  saveEventBtn.addEventListener('click', () => {
   const eventTitle = eventTitleInput.value;
   const eventDate = eventDateInput.value;
   const eventTime = eventTimeInput.value;
  
   if (eventTitle && eventDate && eventTime) {
    // Преобразуем дату в формат "yyyy-MM-dd"
    const formattedDate = new Date(eventDate).toISOString().split('T')[0];
  
    if (!events[formattedDate]) {
     events[formattedDate] = [];
    }
    events[formattedDate].push({ title: eventTitle, time: eventTime });
  
    alert(`Событие "${eventTitle}" добавлено на ${eventDate} в ${eventTime}`);
    popup.style.display = 'none';
    eventTitleInput.value = '';
    eventDateInput.value = '';
    eventTimeInput.value = '';
  
    renderCalendar(); // Обновление календаря для отображения нового события
   } else {
    alert('Пожалуйста, заполните все поля.');
   }
  });
  
  // Инициализация календаря
  renderCalendar();
  
    