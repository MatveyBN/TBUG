const navButtons = document.querySelectorAll('.nav .btn');

navButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Убираем класс "active" у всех кнопок
    navButtons.forEach(btn => btn.classList.remove('active'));
    // Добавляем класс "active" к текущей кнопке
    button.classList.add('active');
  });
});



