document.getElementById('photoInput').onchange = function(event) {
    var reader = new FileReader();
    reader.onload = function() {
        var output = document.getElementById('preview');
        output.src = reader.result;
        output.style.display = 'block';
        var nophoto = document.getElementById("nophoto"); nophoto.remove();
    };
    reader.readAsDataURL(event.target.files[0]);
};

var peraccbtn = document.getElementById('per_acc_btn')
var calendarbtn = document.getElementById('calendar_btn')
var reportsbtn = document.getElementById('reports_btn')
var usermanagebtn = document.getElementById('user_management_btn')
var systemsetupbtn = document.getElementById('system_setup_btn')

peraccbtn.addEventListener("click", function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    calendar_btn.classList.remove("active")
    calendar_btn.classList.add("passiv")
    reports_btn.classList.remove("active")
    reports_btn.classList.add("passiv")
    user_management_btn.classList.remove("active")
    user_management_btn.classList.add("passiv")
    system_setup_btn.classList.remove("active")
    system_setup_btn.classList.add("passiv")
});

calendarbtn.addEventListener("click", function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    peraccbtn.classList.remove("active")
    peraccbtn.classList.add("passiv")
    reports_btn.classList.remove("active")
    reports_btn.classList.add("passiv")
    user_management_btn.classList.remove("active")
    user_management_btn.classList.add("passiv")
    system_setup_btn.classList.remove("active")
    system_setup_btn.classList.add("passiv")
});

reports_btn.addEventListener("click", function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    calendar_btn.classList.remove("active")
    calendar_btn.classList.add("passiv")
    peraccbtn.classList.remove("active")
    peraccbtn.classList.add("passiv")
    user_management_btn.classList.remove("active")
    user_management_btn.classList.add("passiv")
    system_setup_btn.classList.remove("active")
    system_setup_btn.classList.add("passiv")
});

usermanagebtn.addEventListener("click",function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    calendar_btn.classList.remove("active")
    calendar_btn.classList.add("passiv")
    peraccbtn.classList.remove("active")
    peraccbtn.classList.add("passiv")
    system_setup_btn.classList.remove("active")
    system_setup_btn.classList.add("passiv")
    reports_btn.classList.remove("active")
    reports_btn.classList.add("passiv")
})

systemsetupbtn.addEventListener("click", function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    calendar_btn.classList.remove("active")
    calendar_btn.classList.add("passiv")
    peraccbtn.classList.remove("active")
    peraccbtn.classList.add("passiv")
    reports_btn.classList.remove("active")
    reports_btn.classList.add("passiv")
    user_management_btn.classList.remove("active")
    user_management_btn.classList.add("passiv")
})