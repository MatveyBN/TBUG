const navButtons = document.querySelectorAll('.nav .btn');

navButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Убираем класс "active" у всех кнопок
    navButtons.forEach(btn => btn.classList.remove('active'));
    // Добавляем класс "active" к текущей кнопке
    button.classList.add('active');
  });
});


const addCandidateBtn = document.getElementById('addCandidateBtn');
const candidatePopup = document.getElementById('candidatePopup');
const closeCandidatePopup = candidatePopup.querySelector('.close');
const saveCandidateBtn = document.getElementById('saveCandidate');
const candidatesBody = document.getElementById('candidatesBody');
const searchInput = document.getElementById('search');
const positionFilter = document.getElementById('positionFilter');
const statusFilter = document.getElementById('statusFilter');
const startDateInput = document.getElementById('startDate');
const endDateInput = document.getElementById('endDate');
const filterBtn = document.getElementById('filterBtn');

let candidates = [];

// Открытие попапа для добавления кандидата
addCandidateBtn.addEventListener('click', () => {
    candidatePopup.style.display = 'block';
});

// Закрытие попапа
closeCandidatePopup.addEventListener('click', () => {
    candidatePopup.style.display = 'none';
});
// Сохранение информации о кандидате
saveCandidateBtn.addEventListener('click', () => {
  const name = document.getElementById('candidateName').value;
  const position = document.getElementById('candidatePosition').value;
  const resumeInput = document.getElementById('candidateResume');
  const status = document.getElementById('candidateStatus').value;
  const dateAdded = new Date().toLocaleDateString();

  if (name && position && resumeInput.files.length > 0) {
    const resumeFile = resumeInput.files[0];
    const resumeURL = URL.createObjectURL(resumeFile);

    candidates.push({ name, position, resumeURL, status, dateAdded });
    updateCandidatesTable();
    candidatePopup.style.display = 'none';
  } else {
    alert('Пожалуйста, заполните все поля.');
  }
});

// Обновление таблицы кандидатов
function updateCandidatesTable() {
  candidatesBody.innerHTML = '';
  candidates.forEach(candidate => {
    const row = document.createElement('tr');

    const nameCell = document.createElement('td');
    nameCell.textContent = candidate.name;
    row.appendChild(nameCell);

    const positionCell = document.createElement('td');
    positionCell.textContent = candidate.position;
    row.appendChild(positionCell);

    const resumeCell = document.createElement('td');
    const resumeLink = document.createElement('a');
    resumeLink.href = candidate.resumeURL;
    resumeLink.textContent = 'Скачать';
    resumeLink.target = '_blank';
    resumeCell.appendChild(resumeLink);
    row.appendChild(resumeCell);

    const statusCell = document.createElement('td');
    statusCell.textContent = candidate.status;
    row.appendChild(statusCell);

    const dateCell = document.createElement('td');
    dateCell.textContent = candidate.dateAdded;
    row.appendChild(dateCell);

    candidatesBody.appendChild(row);
});
}

// Фильтрация кандидатов
filterBtn.addEventListener('click', () => {
const searchValue = searchInput.value.toLowerCase();
const positionValue = positionFilter.value;
const statusValue = statusFilter.value;
const startDateValue = new Date(startDateInput.value);
const endDateValue = new Date(endDateInput.value);

const filteredCandidates = candidates.filter(candidate => {
    const nameMatch = candidate.name.toLowerCase().includes(searchValue);
    const positionMatch = !positionValue || candidate.position === positionValue; // Исправлено
    const statusMatch = !statusValue || candidate.status === statusValue; // Исправлено
    const dateMatch = candidate.dateAdded >= startDateValue.toLocaleDateString() && candidate.dateAdded <= endDateValue.toLocaleDateString();

    return nameMatch && positionMatch && statusMatch && dateMatch;
});

updateCandidatesTable(filteredCandidates); // Передаем отфильтрованные кандидаты
});

// Функция для обновления таблицы кандидатов с учетом фильтрации
function updateCandidatesTable(filteredCandidates = candidates) { // Добавляем параметр по умолчанию
candidatesBody.innerHTML = '';
filteredCandidates.forEach(candidate => { // Используем filteredCandidates
    const row = document.createElement('tr');

    const nameCell = document.createElement('td');
    nameCell.textContent = candidate.name;
    row.appendChild(nameCell);

    const positionCell = document.createElement('td');
    positionCell.textContent = candidate.position;
    row.appendChild(positionCell);

    const resumeCell = document.createElement('td');
    const resumeLink = document.createElement('a');
    resumeLink.href = candidate.resumeURL;
    resumeLink.textContent = 'Скачать';
    resumeLink.target = '_blank';
    resumeCell.appendChild(resumeLink);
    row.appendChild(resumeCell);

    const statusCell = document.createElement('td');
    statusCell.textContent = candidate.status;
    row.appendChild(statusCell);

    const dateCell = document.createElement('td');
    dateCell.textContent = candidate.dateAdded;
    row.appendChild(dateCell);

    candidatesBody.appendChild(row);
});
}
