document.getElementById('photoInput').onchange = function(event) {
    var reader = new FileReader();
    reader.onload = function() {
        var output = document.getElementById('preview');
        output.src = reader.result;
        output.style.display = 'block';
        var nophoto = document.getElementById("nophoto"); nophoto.remove();
    };
    reader.readAsDataURL(event.target.files[0]);
};

var peraccbtn = document.getElementById('per_acc_btn')
var calendarbtn = document.getElementById('calendar_btn')
var candidatesbtn = document.getElementById('candidates_btn')
var employeesbtn = document.getElementById('employees_btn')
var reportsbtn = document.getElementById('reports_btn')

peraccbtn.addEventListener("click", function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    calendar_btn.classList.remove("active")
    calendar_btn.classList.add("passiv")
    candidates_btn.classList.remove("active")
    candidates_btn.classList.add("passiv")
    employees_btn.classList.remove("active")
    employees_btn.classList.add("passiv")
    reports_btn.classList.remove("active")
    reports_btn.classList.add("passiv")
});

calendarbtn.addEventListener("click", function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    peraccbtn.classList.remove("active")
    peraccbtn.classList.add("passiv")
    candidates_btn.classList.remove("active")
    candidates_btn.classList.add("passiv")
    employees_btn.classList.remove("active")
    employees_btn.classList.add("passiv")
    reports_btn.classList.remove("active")
    reports_btn.classList.add("passiv")
});

candidatesbtn.addEventListener("click", function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    calendar_btn.classList.remove("active")
    calendar_btn.classList.add("passiv")
    peraccbtn.classList.remove("active")
    peraccbtn.classList.add("passiv")
    employees_btn.classList.remove("active")
    employees_btn.classList.add("passiv")
    reports_btn.classList.remove("active")
    reports_btn.classList.add("passiv")
});

employeesbtn.addEventListener("click",function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    calendar_btn.classList.remove("active")
    calendar_btn.classList.add("passiv")
    peraccbtn.classList.remove("active")
    peraccbtn.classList.add("passiv")
    reports_btn.classList.remove("active")
    reports_btn.classList.add("passiv")
    candidates_btn.classList.remove("active")
    candidates_btn.classList.add("passiv")
})

reportsbtn.addEventListener("click", function() {
    this.classList.remove("passiv")
    this.classList.add("active")
    calendar_btn.classList.remove("active")
    calendar_btn.classList.add("passiv")
    peraccbtn.classList.remove("active")
    peraccbtn.classList.add("passiv")
    candidates_btn.classList.remove("active")
    candidates_btn.classList.add("passiv")
    employees_btn.classList.remove("active")
    employees_btn.classList.add("passiv")
})