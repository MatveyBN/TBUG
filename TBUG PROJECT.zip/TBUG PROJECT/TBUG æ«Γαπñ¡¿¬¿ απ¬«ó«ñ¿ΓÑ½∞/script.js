const navButtons = document.querySelectorAll('.nav .btn');

navButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Убираем класс "active" у всех кнопок
    navButtons.forEach(btn => btn.classList.remove('active'));
    // Добавляем класс "active" к текущей кнопке
    button.classList.add('active');
  });
});



let selectedRow = null;

function showProfile(name, position, project, photo, row) {
    const profilePhoto = document.getElementById('profilePhoto');
    profilePhoto.innerHTML = `<img src="${photo}" alt="${name}">`;
    
    const profileDescription = document.getElementById('profileDescription');
    const descriptionHTML = `
        <p><strong>ФИО:</strong> ${name}</p>
        <p><strong>Должность:</strong> ${position}</p>
        <p><strong>Проект:</strong> ${project}</p>
        <p><strong>Дата приема на работу:</strong> 01.01.2020</p>
        <p><strong>Текущий статус:</strong> Активен</p>
    `;
    profileDescription.innerHTML = descriptionHTML;
    
    if (selectedRow !== null) {
        selectedRow.classList.remove('selected');
    }
    selectedRow = row;
    selectedRow.classList.add('selected');
}

