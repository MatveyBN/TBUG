var btn1 = document.getElementById("btn1");
btn1.addEventListener("click", function() {
  btn2.classList.remove("active");
  btn3.classList.remove("active");
  this.classList.add("active");
});

var btn2 = document.getElementById("btn2");
btn2.addEventListener("click", function() {
  this.classList.add("active");
  btn1.classList.remove("active");
  btn3.classList.remove("active");
});

var btn3 = document.getElementById("btn3");
btn3.addEventListener("click", function() {
  this.classList.add("active");
  btn1.classList.remove("active");
  btn2.classList.remove("active");
});

const btn11 = document.querySelector("#btn1");
const regbtn = document.querySelector('.regbtn')

regbtn.addEventListener("click", function(){
  if (btn11.classList.contains('active')){
    regbtn.setAttribute('onclick',window.location.href='/PA hr manager/hr.html')
  }
})



const btn22 = document.querySelector("#btn2");
const regbtn1 = document.querySelector('.regbtn')

regbtn.addEventListener("click", function(){
  if (btn22.classList.contains('active')){
    regbtn1.setAttribute('onclick',window.location.href='/PA supervisor/superv.html')
  }
})



const btn33 = document.querySelector("#btn3");
const regbtn2 = document.querySelector('.regbtn')

regbtn.addEventListener("click", function(){
  if (btn33.classList.contains('active')){
    regbtn2.setAttribute('onclick',window.location.href='/PA admin/admin.html')
  }
})