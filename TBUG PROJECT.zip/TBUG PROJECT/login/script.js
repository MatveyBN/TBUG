var btn1 = document.getElementById("btn1");
btn1.addEventListener("click", function() {
  btn2.classList.remove("active");
  btn3.classList.remove("active");
  this.classList.add("active");
});

var btn2 = document.getElementById("btn2");
btn2.addEventListener("click", function() {
  this.classList.add("active");
  btn1.classList.remove("active");
  btn3.classList.remove("active");
});

var btn3 = document.getElementById("btn3");
btn3.addEventListener("click", function() {
  this.classList.add("active");
  btn1.classList.remove("active");
  btn2.classList.remove("active");
});

let logbtn = document.querySelector('.logbtn')
logbtn.addEventListener("click", function(){
  alert('Email или пароль не верны')
})