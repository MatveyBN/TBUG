const navButtons = document.querySelectorAll('.nav .btn');

navButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Убираем класс "active" у всех кнопок
    navButtons.forEach(btn => btn.classList.remove('active'));
    // Добавляем класс "active" к текущей кнопке
    button.classList.add('active');
  });
});


let selectedRow = null;
let isBlocked = false;

function showProfile(name, position, project, photo, row) {
    const profilePhoto = document.getElementById('profilePhoto');
    profilePhoto.src = photo; // Установим изображение
    
    const profileDescription = document.getElementById('profileDescription');
    const descriptionHTML = `
        <p><strong>ФИО:</strong> ${name}</p>
        <p><strong>Должность:</strong> ${position}</p>
        <p><strong>Проект:</strong> ${project}</p>

        <p><strong>Дата приема на работу:</strong> 01.01.2020</p>
        <p><strong>Текущий статус:</strong> ${isBlocked ? 'Заблокирован' : 'Активен'}</p>
    `;
    profileDescription.innerHTML = descriptionHTML;
    
    if (selectedRow !== null) {
        selectedRow.classList.remove('selected');
    }
    selectedRow = row;
    selectedRow.classList.add('selected');

    // Установка статуса блокировки
    if (isBlocked) {
        selectedRow.classList.add('blocked');
        document.getElementById('toggleBlockButton').innerText = 'Разблокировать';
    } else {
        selectedRow.classList.remove('blocked');
        document.getElementById('toggleBlockButton').innerText = 'Заблокировать';
    }
}

function toggleBlock() {
    if (selectedRow) {
        isBlocked = !isBlocked; // Переключаем статус блокировки
        showProfile(
            selectedRow.cells[1].innerText,
            selectedRow.cells[2].innerText,
            selectedRow.cells[3].innerText,
            selectedRow.cells[0].children[0].src,
            selectedRow
        );
    }
}

function savePassword() {
    const newPassword = document.getElementById('newPassword').value;
    if (newPassword) {
        alert('Пароль успешно изменён!'); // Здесь можно добавить логику для сохранения пароля
        document.getElementById('newPassword').value = ''; // Очистить поле ввода
    } else {
        alert('Введите новый пароль.');
    }
}
